#include <iostream>
#include "goblin.h"
#include "wolf.h"
#include "willow.h"
#include "skeleton.h"
#include "orc.h"
#include "zombie.h"
#include "warrior.h"
#include "mage.h"
#include "priest.h"


/*
    goblin kill - 3xp
    wolf kill - 5xp
    willow kill - 7xp

    skeleton kill - 10xp
    orc kill - 15xp 
    zombie kill - 25xp

*/


int main()
{
    Warrior Warrior;
    Mage Mage;
    Priest Priest;
    Goblin Goblin;
    Wolf Wolf;
    Willow Willow;
    Skeleton Skeleton;
    Orc Orc;
    Zombie Zombie;


    int loop1 = 1;
    while (loop1 == 1)
    {
                
        std::cout << "\t===================\n";
        std::cout << "\t|| ALAMAT NG MGA BAYANI ||\n";
        std::cout << "\t===================\n";

        std::cout << "\t[ A ] Magsimula\n";
        std::cout << "\t[ B ] Umalis\n";



        std::string choice1 = "A";
        do
        {
            while (choice1 != "A" && choice1 != "a" && choice1 != "B" && choice1 != "b")
            {
                std::cout << "\tOops! Mali ang input. Subukan ulit!\n";
                break;
            }

            std::cout << "\tIlagay ang Iyong Pinili: ";
            std::getline(std::cin, choice1);
        } while (choice1 != "A" && choice1 != "a" && choice1 != "B" && choice1 != "b");
        
        




















































































































        if (choice1 == "A" || choice1 == "a")
        {
            std::cout << "\tPaglikha ng Karakter\n\n";

            std::string characterName;
            std::cout << "\tPangalan ng Karakter: ";
            std::getline(std::cin, characterName);

            std::string job = "1";
            do
            {
                while (job != "1" && job != "2" && job != "3")
                {
                    std::cout << "\tDi-wastong input, pakisubukang muli.\n";
                    break;
                }

                std::cout << "\n\n\tPumili ng Trabaho: \n";
                std::cout << "\t[ 1 ] Mandirigma\n";
                std::cout << "\t[ 2 ] Mago\n";
                std::cout << "\t[ 3 ] Pari\n";
                std::cout << "\tIlagay ang Iyong Pinili: ";
                std::getline(std::cin, job);
            } while (job != "1" && job != "2" && job != "3");

            int health;
            int mana;
            int strength;
            int defense;
            int agility;
            int magic;

            if (job == "1")
            {
            
                Warrior.setHealth();
                Warrior.setMana();
                Warrior.setStrength();
                Warrior.setDefense();
                Warrior.setAgility();
                Warrior.setMagic();

                health = Warrior.getHealth();
                mana = Warrior.getMana();
                strength = Warrior.getStrength();
                defense = Warrior.getDefense();
                agility = Warrior.getAgility();
                magic = Warrior.getMagic();
                job = "Mandirigma";
            }
            else if (job == "2")
            {
    
                Mage.setHealth();
                Mage.setMana();
                Mage.setStrength();
                Mage.setDefense();
                Mage.setAgility();
                Mage.setMagic();

                health = Mage.getHealth();
                mana = Mage.getMana();
                strength = Mage.getStrength();
                defense = Mage.getDefense();
                agility = Mage.getAgility();
                magic = Mage.getMagic();
                job = "Mago";
            }
            else if (job == "3")
            {
                
                Priest.setHealth();
                Priest.setMana();
                Priest.setStrength();
                Priest.setDefense();
                Priest.setAgility();
                Priest.setMagic();

                health = Priest.getHealth();
                mana = Priest.getMana();
                strength = Priest.getStrength();
                defense = Priest.getDefense();
                agility = Priest.getAgility();
                magic = Priest.getMagic();
                job = "Pari";
            }









































































            int lvl1 = 0;
            int lvl2 = 0;
            int lvl3 = 0;
            int lvl4 = 0;
            int lvl5 = 0;
            int lvl6 = 0;
            int lvl7 = 0;
            int lvl8 = 0;
            int lvl9 = 0;
            int lvl10 = 0;


            int level = 1;
            int loop2 = 1;
            int need_exp = 0;
            while (loop2 == 1)
            {

                if (level == 1)
                {
                    while (lvl1 == 0)
                    {
                        need_exp = 9;
                        lvl1 = 1;
                    }
                }
                else if (level == 2)
                {
                    while (lvl2 == 0)
                    {
                        need_exp = 16;
                        lvl2 = 1;
                    }
                }
                else if (level == 3)
                {
                    while (lvl3 == 0)
                    {
                        need_exp = 25;
                        lvl3 = 1;
                    }
                }
                else if (level == 4)
                {
                    while (lvl4 == 0)
                    {
                        need_exp = 36;
                        lvl4 = 1;
                    }
                }
                else if (level == 5)
                {
                    while (lvl5 == 0)
                    {
                        need_exp = 49;
                        lvl5 = 1;
                    }
                }
                else if (level == 6)
                {
                    while (lvl6 == 0)
                    {
                        need_exp = 64;
                        lvl6 = 1;
                    }
                }
                else if (level == 7)
                {
                    while (lvl7 == 0)
                    {
                        need_exp = 81;
                        lvl7 = 1;
                    }
                }
                else if (level == 8)
                {
                    while (lvl8 == 0)
                    {
                        need_exp = 100;
                        lvl8 = 1;
                    }
                }
                else if (level == 9)
                {
                    while (lvl9 == 0)
                    {
                        need_exp = 121;
                        lvl9 = 1;
                    }
                }
                else if (level == 10)
                {
                    while (lvl10 == 0)
                    {
                        need_exp = 0;
                        lvl10 = 1;
                    }
                }
                








                std::cout << "\n\tPROPAYL NG KARAKTER\n\n";
                std::cout << "\tPangalan: " << characterName << "\n";
                std::cout << "\tTrabaho: " << job << "\n";
                std::cout << "\tAntas: " << level << "\n";
                std::cout << "\tKalusugan: " << health << "\n";
                std::cout << "\tMana: " << mana << "\n";
                std::cout << "\tLakas: " << strength << "\n";
                std::cout << "\tTibay: " << defense << "\n";
                std::cout << "\tLiksi: " << agility << "\n";
                std::cout << "\tMahika: " << magic << "\n";
                std::cout << "\tKaranasan sa susunod na antas: " << need_exp << "\n";


                std::cout << "\tPagpili ng Misyon\n\n";
                std::cout << "\t[ 1 ] Gubat\n";
                std::cout << "\t[ 2 ] Madilim na Yungib\n";
                std::cout << "\t[ 3 ] Pangunahing Misyon\n";

                std::string choice2 = "1";
                do
                {
                    while (choice2 != "1" && choice2 != "2" && choice2 != "3")
                    {
                        std::cout << "\tDi-wastong input, pakisubukang muli.\n";
                        break;
                    }

                    std::cout << "\tIlagay ang Iyong Pinili: ";
                    std::getline(std::cin, choice2);
                } while (choice2 != "1" && choice2 != "2" && choice2 != "3");

                if (choice2 == "1")
                {
                    std::cout << "\tGubat\n";
                    std::cout << "\t[ 1 ] Goblin\n";
                    std::cout << "\t[ 2 ] Wolf\n";
                    std::cout << "\t[ 3 ] Willow\n";

                    std::string choice3 = "1";
                    do
                    {
                        while (choice3 != "1" && choice3 != "2" && choice3 != "3")
                        {
                            std::cout << "\tDi-wastong input, pakisubukang muli.\n";
                            break;
                        }

                        std::cout << "\tIlagay ang Iyong Pinili: ";
                        std::getline(std::cin, choice3);
                    } while (choice3 != "1" && choice3 != "2" && choice3 != "3");

                    if (choice3 == "1")
                    {
                        Goblin.setHealth();
                        Goblin.setMana();
                        Goblin.setStrength();
                        Goblin.setDefense();
                        Goblin.setAgility();
                        Goblin.setMagic();
                        Goblin.setExp();

                        std::cout << "\tGoblin\n";
                        std::cout << "\tKalusugan: " << Goblin.getHealth() << "\n";
                        std::cout << "\tMana: " << Goblin.getMana() << "\n\n";

                        std::cout << characterName << "Level." << level << "\n";
                        std::cout << "Kalusugan: " << health << "\n";
                        std::cout << "Mana: " << mana << "\n";

                        
                    }
                    
                }
                else if(choice2 == "2")
                {
                    std::cout << "\tMadilim na Yungib\n";
                    std::cout << "\t[ 1 ] Skeleton\n";
                    std::cout << "\t[ 2 ] Orc\n";
                    std::cout << "\t[ 3 ] Zombie\n";

                    std::string choice4 = "1";
                    do
                    {
                        while (choice4 != "1" && choice4 != "2" && choice4 != "3")
                        {
                            std::cout << "\tDi-wastong input, pakisubukang muli.\n";
                            break;
                        }

                        std::cout << "\tIlagay ang Iyong Pinili: ";
                        std::getline(std::cin, choice4);
                    } while (choice4 != "1" && choice4 != "2" && choice4 != "3");
                }









































                else if(choice2 == "3")
                {
                    std::cout << "\tPangunahing Misyon\n";
                }

                    
                    





            }
            
            
































































































































































        }
        else if(choice1 == "B" || choice1 == "b")
        {

        }
        else
        {
            std::cout << "\tDi-wastong pagpili, pakisubukang muli.";
        }
    }


    
    
}
